package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Initialize navigation buttons
        Button btnHistory = findViewById(R.id.btnHistory);
        Button btnAddExpenses = findViewById(R.id.btnAddExpenses);
        Button btnBudget = findViewById(R.id.btnBudget);

        // Initialize profile icon (if in layout)
        ImageView ivProfile = findViewById(R.id.ivProfile);

        // Set up button navigation
        btnAddExpenses.setOnClickListener(v ->
                startActivity(new Intent(this, AddExpenseActivity.class)));

        btnBudget.setOnClickListener(v ->
                startActivity(new Intent(this, BudgetActivity.class)));

        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(this, HistoryActivity.class)));

        // Open Profile page when icon is clicked
        if (ivProfile != null) {
            ivProfile.setOnClickListener(v ->
                    startActivity(new Intent(this, ProfileActivity.class)));
        }
    }

    // Optional toolbar menu (if you're using menu_home.xml)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_profile) {
            startActivity(new Intent(this, ProfileActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
