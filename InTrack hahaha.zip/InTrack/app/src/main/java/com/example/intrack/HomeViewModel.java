package com.example.intrack;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class HomeViewModel extends AndroidViewModel {
    private final InTrackRepository repo;
    public final LiveData<List<Transaction>> transactions;

    public HomeViewModel(@NonNull Application app) {
        super(app);
        repo = new InTrackRepository(app);
        transactions = repo.transactions();
    }

    public void add(Transaction t) {
        repo.add(t);
    }
}
