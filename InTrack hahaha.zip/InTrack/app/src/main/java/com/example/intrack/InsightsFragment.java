package com.example.intrack;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;

public class InsightsFragment extends Fragment {

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_insights, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);

        LineChart chart = v.findViewById(R.id.lineChart);

        // Dummy monthly totals just to show a line. Replace with real data later.
        float[] totals = { 500f, 800f, 650f, 900f, 1200f, 1100f };

        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < totals.length; i++) {
            entries.add(new Entry(i, totals[i]));
        }

        LineDataSet set = new LineDataSet(entries, "Monthly Spending");
        set.setDrawCircles(true);
        set.setDrawValues(false);
        set.setMode(LineDataSet.Mode.CUBIC_BEZIER);
        set.setDrawFilled(true);

        chart.setData(new LineData(set));
        chart.getLegend().setEnabled(false);
        chart.getAxisRight().setEnabled(false);

        XAxis x = chart.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setGranularity(1f);

        chart.getDescription().setEnabled(false);
        chart.invalidate(); // render
    }
}
