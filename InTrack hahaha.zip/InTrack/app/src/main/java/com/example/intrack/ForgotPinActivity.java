package com.example.intrack;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ForgotPinActivity extends AppCompatActivity {
    private static final String PREFS = "auth_prefs";
    private static final String KEY_PIN = "mpin";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_forgot_pin);

        Button btn = findViewById(R.id.btnReset);
        btn.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            prefs.edit().remove(KEY_PIN).apply(); // clear saved PIN
            Toast.makeText(this, "PIN cleared. Set a new PIN.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, PinActivity.class)); // go set a new one
            finish();
        });
    }
}
