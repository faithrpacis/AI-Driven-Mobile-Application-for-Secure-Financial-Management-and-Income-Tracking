package com.example.intrack;

import android.content.Context;
import androidx.lifecycle.LiveData;
import java.util.List;
import java.util.concurrent.Executors;

public class InTrackRepository {
    private final TxDao txDao;

    public InTrackRepository(Context ctx) {
        txDao = AppDatabase.get(ctx).txDao();
    }

    public LiveData<List<Transaction>> transactions() {
        return txDao.getAll();
    }

    public void add(Transaction t) {
        Executors.newSingleThreadExecutor().execute(() -> txDao.insert(t));
    }
}
