package com.example.intrack;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TxDao {
    @Query("SELECT * FROM transactions ORDER BY dateMillis DESC")
    LiveData<List<Transaction>> getAll();

    @Insert
    void insert(Transaction tx);
}
