package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PinActivity extends AppCompatActivity {

    private EditText etPin;
    private TextView tvTitle;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_pin);

        tvTitle = findViewById(R.id.tvTitle);
        etPin   = findViewById(R.id.etPin);
        Button btn = findViewById(R.id.btnContinue);

        SessionManager sm = new SessionManager(this);
        final boolean firstTime = !sm.hasPin();

        tvTitle.setText(firstTime ? "Set a new 4-digit PIN" : "Enter PIN");

        btn.setOnClickListener(v -> {
            String pin = etPin.getText().toString().trim();

            if (pin.length() != 4) {
                etPin.setError("Enter 4 digits");
                return;
            }

            if (firstTime) {
                sm.setPin(pin);          // save new PIN
                toast("PIN set");
                goHome();
            } else {
                if (pin.equals(sm.getPin())) {
                    goHome();
                } else {
                    etPin.setError("Incorrect PIN");
                }
            }
        });
    }

    private void goHome() {
        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }
}
