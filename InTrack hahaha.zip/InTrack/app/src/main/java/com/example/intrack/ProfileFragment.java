package com.example.intrack;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private EditText etName, etEmail;
    private SharedPreferences prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);

        etName = v.findViewById(R.id.etName);
        etEmail = v.findViewById(R.id.etEmail);
        Button btnSave = v.findViewById(R.id.btnSave);

        // SharedPreferences to store user info locally
        prefs = requireContext().getSharedPreferences("user_profile", Context.MODE_PRIVATE);

        // Load saved data (if any)
        etName.setText(prefs.getString("name", ""));
        etEmail.setText(prefs.getString("email", ""));

        // Save button action
        btnSave.setOnClickListener(view -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();

            prefs.edit()
                    .putString("name", name)
                    .putString("email", email)
                    .apply();

            Toast.makeText(requireContext(), "Profile saved", Toast.LENGTH_SHORT).show();
        });
    }
}
