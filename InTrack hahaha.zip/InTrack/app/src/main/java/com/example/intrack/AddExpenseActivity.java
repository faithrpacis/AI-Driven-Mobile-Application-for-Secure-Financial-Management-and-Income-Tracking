package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AddExpenseActivity extends AppCompatActivity {

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void openForm(String category) {
        toast("Opening form: " + (category == null || category.isEmpty() ? "(new)" : category));
        Intent i = new Intent(AddExpenseActivity.this, AddExpenseFormActivity.class);
        i.putExtra("category", category);
        startActivity(i);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expenses);

        // Quick proof this screen loaded
        toast("Expenses screen loaded");

        // Tabs
        TextView tabHistory     = findViewById(R.id.tabHistory);
        TextView tabAddExpenses = findViewById(R.id.tabAddExpenses);
        TextView tabBudget      = findViewById(R.id.tabBudget);

        // Bottom menu
        ImageView navHome     = findViewById(R.id.navHome);
        ImageView navInsights = findViewById(R.id.navInsights);
        ImageView navProfile  = findViewById(R.id.navProfile);

        // Category tiles (may be null if IDs missing in XML)
        LinearLayout tileFood          = findViewById(R.id.tileFood);
        LinearLayout tileTransport     = findViewById(R.id.tileTransport);
        LinearLayout tileMedicine      = findViewById(R.id.tileMedicine);
        LinearLayout tileGroceries     = findViewById(R.id.tileGroceries);
        LinearLayout tileRent          = findViewById(R.id.tileRent);
        LinearLayout tileGifts         = findViewById(R.id.tileGifts);
        LinearLayout tileSavings       = findViewById(R.id.tileSavings);
        LinearLayout tileEntertainment = findViewById(R.id.tileEntertainment);
        LinearLayout tileAdd           = findViewById(R.id.tileAdd);

        // --- Tabs actions ---
        if (tabHistory != null) {
            tabHistory.setOnClickListener(v -> {
                startActivity(new Intent(AddExpenseActivity.this, HomeActivity.class));
                finish();
            });
        } else toast("tabHistory not found in layout");

        if (tabBudget != null) {
            tabBudget.setOnClickListener(v -> {
                startActivity(new Intent(AddExpenseActivity.this, BudgetActivity.class));
                finish();
            });
        } else toast("tabBudget not found in layout");

        // --- Bottom menu actions ---
        if (navHome != null) {
            navHome.setOnClickListener(v ->
                    startActivity(new Intent(AddExpenseActivity.this, HomeActivity.class))
            );
        } else toast("navHome not found in layout");

        if (navInsights != null) {
            navInsights.setOnClickListener(v ->
                    startActivity(new Intent(AddExpenseActivity.this, InsightsActivity.class))
            );
        } // optional toast omitted if you haven't created InsightsActivity yet

        if (navProfile != null) {
            navProfile.setOnClickListener(v ->
                    startActivity(new Intent(AddExpenseActivity.this, ProfileActivity.class))
            );
        } // optional toast omitted if you haven't created ProfileActivity yet

        // --- Tile clicks -> open form (guard each to avoid crashes if ID missing) ---
        if (tileFood != null)          tileFood.setOnClickListener(v -> openForm("Food"));       else toast("tileFood missing");
        if (tileTransport != null)     tileTransport.setOnClickListener(v -> openForm("Transport")); else toast("tileTransport missing");
        if (tileMedicine != null)      tileMedicine.setOnClickListener(v -> openForm("Medicine")); else toast("tileMedicine missing");
        if (tileGroceries != null)     tileGroceries.setOnClickListener(v -> openForm("Groceries")); else toast("tileGroceries missing");
        if (tileRent != null)          tileRent.setOnClickListener(v -> openForm("Rent"));       else toast("tileRent missing");
        if (tileGifts != null)         tileGifts.setOnClickListener(v -> openForm("Gifts"));     else toast("tileGifts missing");
        if (tileSavings != null)       tileSavings.setOnClickListener(v -> openForm("Savings")); else toast("tileSavings missing");
        if (tileEntertainment != null) tileEntertainment.setOnClickListener(v -> openForm("Entertainment")); else toast("tileEntertainment missing");
        if (tileAdd != null)           tileAdd.setOnClickListener(v -> openForm(""));            else toast("tileAdd missing");
    }
}
