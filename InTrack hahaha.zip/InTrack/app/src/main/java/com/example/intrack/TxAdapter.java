package com.example.intrack;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class TxAdapter extends RecyclerView.Adapter<TxAdapter.VH> {
    private final List<Transaction> data = new ArrayList<>();

    static class VH extends RecyclerView.ViewHolder {
        final TextView title, amount;
        VH(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            amount = v.findViewById(R.id.tvAmount);
        }
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_transaction, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Transaction t = data.get(position);
        h.title.setText(t.title);
        h.amount.setText(String.format("₱%.2f", t.amount));
    }

    @Override
    public int getItemCount() { return data.size(); }

    public void submit(List<Transaction> items) {
        data.clear();
        if (items != null) data.addAll(items);
        notifyDataSetChanged();
    }
}
