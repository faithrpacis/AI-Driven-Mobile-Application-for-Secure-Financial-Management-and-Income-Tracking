package com.example.intrack;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF = "intrack.session";
    private static final String KEY_LOGGED_IN = "logged_in";
    private static final String KEY_PIN = "pin"; // null/empty if no PIN set yet

    private final SharedPreferences sp;

    public SessionManager(Context ctx) {
        sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public boolean isLoggedIn() { return sp.getBoolean(KEY_LOGGED_IN, false); }
    public void setLoggedIn(boolean v) { sp.edit().putBoolean(KEY_LOGGED_IN, v).apply(); }

    public String getPin() { return sp.getString(KEY_PIN, ""); }
    public boolean hasPin() { return !getPin().isEmpty(); }
    public void setPin(String pin) { sp.edit().putString(KEY_PIN, pin).apply(); }
    public void clear() { sp.edit().clear().apply(); }
}
