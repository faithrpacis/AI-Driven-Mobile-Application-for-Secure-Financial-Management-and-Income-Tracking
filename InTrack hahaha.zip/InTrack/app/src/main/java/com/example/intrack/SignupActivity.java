package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private EditText etName, etEmail, etPassword, etConfirmPassword;
    private Button btnSignup;
    private TextView tvLoginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // IDs must match those in your signup XML
        etName            = findViewById(R.id.etName);
        etEmail           = findViewById(R.id.etEmail);
        etPassword        = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnSignup         = findViewById(R.id.btnSignup);
        tvLoginLink       = findViewById(R.id.tvLoginLink);

        // Sign up button
        btnSignup.setOnClickListener(v -> {
            String name     = etName.getText().toString().trim();
            String email    = etEmail.getText().toString().trim();
            String pass     = etPassword.getText().toString().trim();
            String confirm  = etConfirmPassword.getText().toString().trim();

            if (name.isEmpty())    { etName.setError("Enter your name"); return; }
            if (email.isEmpty())   { etEmail.setError("Enter your email"); return; }
            if (pass.isEmpty())    { etPassword.setError("Enter password"); return; }
            if (confirm.isEmpty()) { etConfirmPassword.setError("Confirm password"); return; }
            if (!pass.equals(confirm)) {
                etConfirmPassword.setError("Passwords do not match");
                return;
            }

            // TODO: Save the new user in your database or Firebase

            // After successful registration → mark logged in and go to PIN
            SessionManager sm = new SessionManager(this);
            sm.setLoggedIn(true);

            Intent i = new Intent(SignupActivity.this, PinActivity.class);
            startActivity(i);
            finish();
        });

        // Already have an account? → Go to Login
        tvLoginLink.setOnClickListener(v -> {
            startActivity(new Intent(SignupActivity.this, LoginActivity.class));
            finish();
        });
    }
}
