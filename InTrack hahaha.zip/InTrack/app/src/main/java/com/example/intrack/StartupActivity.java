package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class StartupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_startup); // your logo screen

        new Handler().postDelayed(() -> {
            SessionManager sm = new SessionManager(this);
            if (sm.isLoggedIn()) {
                // already has an account -> go straight to PIN
                startActivity(new Intent(this, PinActivity.class));
            } else {
                // first time / logged out -> go to auth (login/sign up)
                startActivity(new Intent(this, LoginActivity.class));
            }
            finish();
        }, 800); // short splash delay
    }
}
