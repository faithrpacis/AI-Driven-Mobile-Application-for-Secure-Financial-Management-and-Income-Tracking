package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etPass;
    private Button btnLogin;
    private TextView tvForgot, tvSignup;
    private CheckBox cbRemember;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Views
        etEmail    = findViewById(R.id.etEmail);
        etPass     = findViewById(R.id.etPassword);
        btnLogin   = findViewById(R.id.btnLogin);
        tvForgot   = findViewById(R.id.tvForgot);
        tvSignup   = findViewById(R.id.tvSignupAction);
        cbRemember = findViewById(R.id.cbRemember);

        // Log In → PIN
        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String pass  = etPass.getText().toString().trim();

            if (email.isEmpty()) { etEmail.setError("Enter email"); return; }
            if (pass.isEmpty())  { etPass.setError("Enter password"); return; }

            // TODO: replace with real auth check
            // If success:
            SessionManager sm = new SessionManager(this);
            sm.setLoggedIn(true); // persist session; "Remember me" UX can be handled later

            // Go to PIN (create or verify), then Home
            Intent i = new Intent(LoginActivity.this, PinActivity.class);
            startActivity(i);
            finish(); // prevent back to Login
        });

        // Forgot PIN (stub — create ForgotPinActivity or change target if you don’t have it)
        tvForgot.setOnClickListener(v -> {
            // If you don't have ForgotPinActivity yet, comment this line or create the Activity.
            startActivity(new Intent(LoginActivity.this, ForgotPinActivity.class));
        });

        // Sign Up
        tvSignup.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, SignupActivity.class))
        );
    }
}
