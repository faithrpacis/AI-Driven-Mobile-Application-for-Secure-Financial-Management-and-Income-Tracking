package com.example.intrack;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "transactions")
public class Transaction {
    @PrimaryKey(autoGenerate = true) public long id;
    public String title;
    public String category;     // e.g., Food, Transport
    public double amount;       // negative = expense, positive = income
    public long dateMillis;     // System.currentTimeMillis()
}
