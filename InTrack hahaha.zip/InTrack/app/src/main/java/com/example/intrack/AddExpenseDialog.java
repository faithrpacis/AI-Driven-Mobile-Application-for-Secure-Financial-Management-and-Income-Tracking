package com.example.intrack;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;

public class AddExpenseDialog extends DialogFragment {

    public static void show(androidx.fragment.app.FragmentManager fm) {
        new AddExpenseDialog().show(fm, "addExpense");
    }

    @NonNull @Override
    public Dialog onCreateDialog(Bundle b) {
        var v = LayoutInflater.from(requireContext())
                .inflate(R.layout.dialog_add_expense, null);

        EditText etTitle  = v.findViewById(R.id.etTitle);
        EditText etAmount = v.findViewById(R.id.etAmount);
        Spinner  spCat    = v.findViewById(R.id.spCategory);

        return new AlertDialog.Builder(requireContext())
                .setTitle("Add Expense")
                .setView(v)
                .setPositiveButton("Save", (d, w) -> {
                    String title = etTitle.getText().toString().trim();
                    String cat   = spCat.getSelectedItem() != null
                            ? spCat.getSelectedItem().toString()
                            : "Other";
                    double amt   = parseDoubleSafe(etAmount.getText().toString());

                    Transaction t = new Transaction();
                    t.title = title.isEmpty() ? "Expense" : title;
                    t.category = cat;
                    t.amount = -Math.abs(amt);                 // expense = negative
                    t.dateMillis = System.currentTimeMillis();

                    new ViewModelProvider(requireActivity())
                            .get(HomeViewModel.class)
                            .add(t);
                })
                .setNegativeButton("Cancel", null)
                .create();
    }

    private static double parseDoubleSafe(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return 0d; }
    }
}
