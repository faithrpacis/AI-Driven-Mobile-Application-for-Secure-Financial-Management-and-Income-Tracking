package com.example.intrack;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.Calendar;

public class AddExpenseFormActivity extends AppCompatActivity {

    private EditText etDate, etCategory, etAmount, etTitle, etMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense_form);
        Toast.makeText(this, "Form loaded", Toast.LENGTH_SHORT).show();


        // Views
        etDate     = findViewById(R.id.etDate);
        etCategory = findViewById(R.id.etCategory);
        etAmount   = findViewById(R.id.etAmount);
        etTitle    = findViewById(R.id.etTitle);
        etMessage  = findViewById(R.id.etMessage);
        MaterialButton btnSave = findViewById(R.id.btnSave);

        // Back button (top bar)
        ImageView btnBack = findViewById(R.id.btnBack);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish()); // returns to Add Expenses screen
        }

        // Prefill category when launched from a tile
        String category = getIntent().getStringExtra("category");
        if (category != null && !category.isEmpty()) {
            etCategory.setText(category);
        }

        // Optional: prefill today's date if empty
        if (etDate.getText().toString().trim().isEmpty()) {
            Calendar c = Calendar.getInstance();
            String today = String.format("%02d/%02d/%d",
                    c.get(Calendar.MONTH) + 1,
                    c.get(Calendar.DAY_OF_MONTH),
                    c.get(Calendar.YEAR));
            etDate.setText(today);
        }

        // Date picker
        etDate.setOnClickListener(v -> showDatePicker());

        // Save action (basic validation)
        btnSave.setOnClickListener(v -> {
            String date = etDate.getText().toString().trim();
            String cat  = etCategory.getText().toString().trim();
            String amt  = etAmount.getText().toString().trim();
            String ttl  = etTitle.getText().toString().trim();

            if (date.isEmpty()) { toast("Please select a date"); return; }
            if (cat.isEmpty())  { toast("Please enter a category"); return; }
            if (amt.isEmpty())  { toast("Please enter an amount"); return; }
            if (ttl.isEmpty())  { toast("Please enter an expense title"); return; }

            // Amount numeric check
            try {
                double value = Double.parseDouble(amt.replace(",", ""));
                if (value <= 0) { toast("Amount must be greater than 0"); return; }
            } catch (NumberFormatException e) {
                toast("Amount must be a valid number");
                return;
            }

            // TODO: Persist to DB / API here
            toast("Expense saved");
            finish(); // go back to previous screen
        });
    }

    private void showDatePicker() {
        final Calendar c = Calendar.getInstance();
        int y = c.get(Calendar.YEAR);
        int m = c.get(Calendar.MONTH);
        int d = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog dpd = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    String pretty = String.format("%02d/%02d/%d", month + 1, dayOfMonth, year);
                    etDate.setText(pretty);
                },
                y, m, d
        );
        dpd.show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
