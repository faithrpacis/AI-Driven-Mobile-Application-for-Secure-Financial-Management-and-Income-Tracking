package com.example.intrack;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Top/back
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        // Menu rows
        LinearLayout btnEditProfile = findViewById(R.id.btnEditProfile);
        LinearLayout btnSettings    = findViewById(R.id.btnSettings);
        LinearLayout btnChatbot     = findViewById(R.id.btnChatbot);
        LinearLayout btnLogout      = findViewById(R.id.btnLogout);
        LinearLayout btnAbout       = findViewById(R.id.btnAbout);

        btnEditProfile.setOnClickListener(v ->
                startActivity(new Intent(this, EditProfileActivity.class)));

        btnSettings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        btnChatbot.setOnClickListener(v ->
                startActivity(new Intent(this, ChatbotActivity.class)));

        btnAbout.setOnClickListener(v ->
                startActivity(new Intent(this, AboutActivity.class)));

        // Logout
        btnLogout.setOnClickListener(v -> {
            SessionManager sm = new SessionManager(this);
            sm.clear(); // clear login + pin; use sm.setLoggedIn(false) if you prefer keeping PIN
            Intent i = new Intent(this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });

        // Bottom nav
        ImageView navHome     = findViewById(R.id.navHome);
        ImageView navInsights = findViewById(R.id.navInsights);
        ImageView navProfile  = findViewById(R.id.navProfile);

        navHome.setOnClickListener(v ->
                startActivity(new Intent(this, HomeActivity.class)));

        navInsights.setOnClickListener(v ->
                startActivity(new Intent(this, InsightsActivity.class)));

        navProfile.setOnClickListener(v -> {}); // already here
    }
}
